window.onload = function() {
    alert("¡Bienvenido a mi página web!");
  }

