window.onload = function() {
    var clockElement = document.getElementById("reloj");
  
    function updateTime() {
      var d = new Date();
      var timeString = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
      clockElement.innerHTML = timeString;
    }
  
    updateTime();
    setInterval(updateTime, 1000); 
  };