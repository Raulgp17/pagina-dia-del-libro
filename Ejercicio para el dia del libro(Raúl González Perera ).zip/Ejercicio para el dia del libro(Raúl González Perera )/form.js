function validarFormulario() {
    var nombre = document.getElementById('nombre').value;
    var email = document.getElementById('email').value;
    var opinion = document.getElementById('opinion').value;

    // Validación básica
    if (nombre === '' || email === '' || opinion === '') {
      alert('Por favor, completa todos los campos.');
      return false; 
    }
    
    return true; 
  }